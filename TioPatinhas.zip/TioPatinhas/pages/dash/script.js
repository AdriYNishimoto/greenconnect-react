const createChart = (ctxId, data) => {
    const ctx = document.getElementById(ctxId).getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Preço',
                data: data,
                borderColor: '#fff',
                backgroundColor: 'rgba(255, 255, 255, 0.1)',
                borderWidth: 2,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    display: false,
                },
                y: {
                    display: false,
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
};

createChart('bitcoinChart', [50000, 52000, 48000, 51000, 53000, 52000]);
createChart('litecoinChart', [8000, 8200, 7800, 7900, 8100, 8000]);
createChart('ethereumChart', [27000, 28000, 26000, 27500, 28500, 28000]);
createChart('solanaChart', [14000, 14500, 13500, 13800, 14200, 14000]);
createChart('mainChart', [30000, 35000, 32000, 34000, 37000, 36000]);
createChart('liveMarketChart', [12000, 12500, 12200, 12400, 12600, 12500]);